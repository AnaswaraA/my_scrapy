import scrapy
from ..items import AbrasivesparserItem


headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "accept-encoding": "gzip, deflate",
            "accept-language": " en-GB,en-US;q=0.9,en;q=0.8 ",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (X11; Linux  x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36"
        }
url = 'https://fandfind.com/product-category/abrasives/'



class AbrassiveSpider(scrapy.Spider):
    name = "abrassive"

    def start_requests(self):
        req=scrapy.Request(url,headers=headers)
        yield req
    def parse(self,response):
        link_xpath = response.xpath('//div[@class="image-fade_in_back"]/a/@href')
        for link in link_xpath:
            yield response.follow(link.get(), callback=self.parse_products , headers=headers)

    def parse_products(self, response):

        name = response.xpath('//h1/text()').get()
        names = name.split("\n\t")
        price = response.xpath('//bdi/text()').get()
        currency = response.xpath('//span[@class="woocommerce-Price-currencySymbol"]/text()').get()
        SKU = response.xpath('//span[@class="sku"]/text()').get()
        breadcrumbs = response.xpath('//nav/a/text()').extract()
        string_breadcumbs = ', '.join(breadcrumbs)
        mfgno = response.xpath('//div[contains(@class,"woocommerce")]/p/text()').get()
        clean_mfgn0 = mfgno.split(":")


        items = AbrasivesparserItem()
        items['product_name'] = names[1]
        items['price'] = price
        items['currency'] = currency
        items['SKU'] = SKU
        items['breadcrumbs'] = string_breadcumbs
        items['MfgPartNo'] = clean_mfgn0[1]
        yield items





# TO RUN : scrapy crawl -s MONGODB_URL="mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false" -s MONGODB_DATABASE="abrasives_database" abrassive

